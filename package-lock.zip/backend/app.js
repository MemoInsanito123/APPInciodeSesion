//express nos permite generar un servidor local en un puerto especifico que nos ayuda a leer peticiones HTTP
const express = require('express');
//express-session nos permite almacenar cookies dentro de nuestro navegador para guardar sesiones
const session = require('express-session');
//body-parser es un middleware para express que se utiliza para analizar el cuerpo de las solicitudes HTTP entrantes
const bodyParser = require('body-parser');
//se utiliza en Node.js para importar un módulo
const authRoutes = require('./auth');
//importamos el modulo db para la conexion a la base de datos
const db = require('./db.js');
//Generamos una instancia para express
const app = express();
//Declaramos una variable para el puerto del servidor local
const PORT = 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: false }));
//Para que la informacion se transforme en objetos 
app.use(bodyParser.json());
//Para las sesiones
app.use(session({
    secret: 'tu_secreto', // Cambia esto
    resave: false,
    saveUninitialized: true
}));

// Rutas
app.use('/auth', authRoutes);

// Servir archivos estáticos (frontend), es decir desde cualquier ruta dentro del directorio(carpeta) frontend es posible acceder a los archivos. Por ejemplo localhost:3000/index.html
app.use(express.static('frontend'));

//Correr el servidor de forma local en el puerto indicado
app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});