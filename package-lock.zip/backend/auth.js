const express = require('express');
const router = express.Router();
const db = require('./db');

router.post('/login', (req, res) => {
    const { correo, password } = req.body;

    // Verificar si es usuario
    const userQuery = 'SELECT * FROM cliente WHERE correo_electronico_cliente = ? AND password_cliente = ?';
    db.execute(userQuery, [correo, password], (err, results) => {
        if (err) return res.status(500).send('Error en la consulta');

        if (results.length > 0) {
            req.session.usuario = correo;
            return res.redirect('/index.html'); // Redirige a la página de inicio
        }

        // Verificar si es administrador
        const adminQuery = 'SELECT * FROM administrador WHERE correo_electronico_administrador = ? AND password_administrador = ?';
        db.execute(adminQuery, [correo, password], (err, results) => {
            if (err) return res.status(500).send('Error en la consulta');

            if (results.length > 0) {
                req.session.admin = correo;
                return res.redirect('/admin.html'); // Redirige a la página del administrador
            } else {
                return res.status(401).send('Credenciales incorrectas');
            }
        });
    });
});

module.exports = router;
